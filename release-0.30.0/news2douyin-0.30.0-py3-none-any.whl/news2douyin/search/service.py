from __future__ import annotations

from dataclasses import dataclass
import json
import re

from sqlalchemy import func, text, and_, inspect
from sqlmodel import Session, or_, select

from ..storage.models import Article, ArticleEventLink, Event, CollectedObservation, TaskRecord, RunRecord
from .dates import date_range
from .index import index_available
from ..storage.sql import time_value
from ..storage.queries import count_keys, page_rows


@dataclass
class SearchPage:
    items: list
    total: int
    offset: int
    limit: int
    search_backend: str
    search_warning: str = ''

    def envelope(self, items=None):
        return {'items': self.items if items is None else items, 'total': self.total,
                'offset': self.offset, 'limit': self.limit,
                'has_more': self.offset + len(self.items) < self.total,
                'search_backend': self.search_backend, **({'search_warning':self.search_warning} if self.search_warning else {})}


def _text_matches(columns, query):
    return or_(*(func.lower(c).contains(query.lower(), autoescape=True) for c in columns))


def _json_string_member(column, value):
    return column.contains(json.dumps(value, ensure_ascii=False), autoescape=True)


def _terms(query, mode):
    if len(query) > 200:
        raise ValueError('query must be at most 200 characters')
    if mode not in {'contains', 'terms'}:
        raise ValueError('mode must be contains or terms')
    # Plain text only: user input is never interpreted as an FTS operator.
    terms = [query.strip()] if mode == 'contains' else query.split()
    if len(terms) > 10:
        raise ValueError('query must have at most 10 terms')
    return [term for term in terms if term]


def _match(model, columns, term, indexed, name):
    predicate = _text_matches(columns, term)
    # Trigram FTS cannot answer short terms; SQLite LIKE is also needed for
    # literal punctuation/wildcards and Unicode characters with different folding.
    if indexed is True and len(term) >= 3 and re.fullmatch(r'[a-zA-Z0-9\u4e00-\u9fff ]+', term):
        table = model.__tablename__ + '_fts'
        subquery = select(text('rowid')).select_from(text(table)).where(text(f'{table} MATCH :{name}'))
        subquery = subquery.params(**{name: '"' + term.replace('"', '""') + '"'})
        predicate = model.id.in_(subquery) & predicate
    return predicate


def _page(session, stmt, order, *, offset, limit, indexed, key=None, name=None):
    if offset < 0 or limit < 1 or limit > 500:
        raise ValueError('offset must be nonnegative and limit must be 1–500')
    entity=stmt.column_descriptions[0].get('entity')
    if key is None:
        if entity is None:
            raise ValueError('A pagination count key is required for a non-entity query')
        primary=inspect(entity).primary_key
        if len(primary)!=1:
            raise ValueError('An explicit pagination count key is required for a composite entity')
        key=primary[0]
    query_name=name or 'search.'+getattr(entity,'__tablename__','results')
    # Project only identity into the unpaginated count. Joins/distinct/grouping
    # remain the caller's business relation; a join is not silently deduplicated.
    total = count_keys(session,stmt,key,name=query_name+'.count')
    items = page_rows(session,stmt.order_by(*order),offset=offset,limit=limit,name=query_name+'.page')
    if session.bind.dialect.name=='postgresql':
        backend='pg_trgm+literal' if indexed=='pg_trgm' else 'pg_sql_literal_degraded'
        warning='' if indexed=='pg_trgm' else getattr(session.bind,'_n2d_search_warning','') or 'PostgreSQL pg_trgm 索引不可用，当前使用字面文本扫描。'
    else:backend,warning=('fts5_trigram+literal' if indexed else 'sql_literal'),''
    return SearchPage(items,total,offset,limit,backend,warning)


def _time_predicate(column, start, end):
    # Both dialects compare instants, preserving legacy offsets and invalid-date NULLs.
    conditions = []
    if start:
        conditions.append(time_value(column) >= time_value(start))
    if end:
        conditions.append(time_value(column) < time_value(end))
    return and_(*conditions)


def article_page(session: Session, *, query='', country='', category='', duplicates='any', limit=50, offset=0, mode='contains',
                 period='all', date_from='', date_to='', time_field='published', timezone='', task_id='', profile_name='', event_key=''):
    if duplicates not in {'any', 'yes', 'no'}:
        raise ValueError('duplicates must be any, yes or no')
    indexed = index_available(session)
    stmt = select(Article)
    if event_key:
        stmt = stmt.where(Article.article_key.in_(select(ArticleEventLink.article_key).where(ArticleEventLink.event_key == event_key)))
    for i, term in enumerate(_terms(query, mode)):
        stmt = stmt.where(_match(Article, [Article.title, Article.content, Article.source_domain], term, indexed, f'article_term_{i}'))
    if country:
        stmt = stmt.where(Article.country == country)
    if category:
        stmt = stmt.where(_json_string_member(Article.category_tags_json, category))
    if duplicates in {'yes', 'no'}:
        stmt = stmt.where(Article.is_duplicate == (duplicates == 'yes'))
    if time_field not in {'published', 'collected', 'created'}:
        raise ValueError('time_field must be published, collected or created')
    start, end = date_range(period, date_from, date_to, timezone)
    observations = (select(CollectedObservation.article_key)
        .outerjoin(TaskRecord, TaskRecord.task_id == CollectedObservation.scope_id)
        .outerjoin(RunRecord, RunRecord.run_key == CollectedObservation.scope_id))
    # Capture repeated collections too; fetched_at alone loses older collection days.
    if task_id:
        observations = observations.where(CollectedObservation.scope_id == task_id)
    if profile_name:
        observations = observations.where(or_(TaskRecord.profile_name == profile_name, RunRecord.profile_name == profile_name))
    if (start or end) and time_field == 'collected':
        observations = observations.where(_time_predicate(func.coalesce(TaskRecord.created_at, RunRecord.started_at), start, end))
        matched = Article.article_key.in_(observations)
        if not task_id and not profile_name:
            no_history = ~Article.article_key.in_(select(CollectedObservation.article_key))
            matched = or_(matched, no_history & _time_predicate(Article.fetched_at, start, end))
        stmt = stmt.where(matched)
    else:
        if task_id or profile_name:
            stmt = stmt.where(Article.article_key.in_(observations))
        if start or end:
            column = Article.published_at if time_field == 'published' else Article.created_at
            stmt = stmt.where(_time_predicate(column, start, end))
    return _page(session, stmt, [Article.id.desc()], offset=offset, limit=limit, indexed=indexed,
                 key=Article.id,name='search.articles')


def event_query(session: Session, *, query='', country='', topic='', mode='contains'):
    indexed = index_available(session)
    from ..storage.models import EventState
    stmt = select(Event).where(~Event.event_key.in_(select(EventState.event_key).where(EventState.merged_into != None)))
    for i, term in enumerate(_terms(query, mode)):
        event_match = _match(Event, [Event.event_title, Event.summary, Event.topic], term, indexed, f'event_term_{i}')
        article_match = _match(Article, [Article.title, Article.content, Article.source_domain], term, indexed, f'source_term_{i}')
        linked = select(ArticleEventLink.event_key).join(Article, Article.article_key == ArticleEventLink.article_key).where(article_match)
        stmt = stmt.where(or_(event_match, Event.event_key.in_(linked)))
    if country:
        stmt = stmt.where(or_(_json_string_member(Event.countries_json, country), Event.market_scope == country))
    if topic:
        stmt = stmt.where(Event.topic == topic)
    return stmt

def event_page(session: Session, *, query='', country='', topic='', limit=50, offset=0, mode='contains'):
    stmt = event_query(session,query=query,country=country,topic=topic,mode=mode)
    return _page(session,stmt,[Event.last_seen_at.desc(),Event.id.desc()],offset=offset,limit=limit,indexed=index_available(session),
                 key=Event.id,name='search.events')


def search_articles(session: Session, *, limit=50, **kwargs):
    return article_page(session, limit=max(1, min(limit, 500)), **kwargs).items


def search_events(session: Session, *, limit=50, **kwargs):
    return event_page(session, limit=max(1, min(limit, 500)), **kwargs).items
