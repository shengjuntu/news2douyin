// Run against the local database produced by smoke_structured_scripts.py.
const {chromium} = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
(async () => {
  const [base, fixture, out] = process.argv.slice(2);
  if (!out) throw new Error('Usage: node smoke_structured_browser.cjs BASE FIXTURE_REPORT OUTPUT');
  const seed = JSON.parse(await fs.readFile(fixture, 'utf8'));
  await fs.mkdir(out, {recursive:true});
  const browser = await chromium.launch({headless:true, executablePath:process.env.BROWSER_BIN || undefined, args:['--no-sandbox']});
  const page = await browser.newPage({viewport:{width:1440,height:1050}});
  const checks = [], errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  const body = () => page.locator('.block-card[data-block-id="body_1"]');
  const read = async key => (await page.request.get(base + '/api/scripts/' + key)).json();
  const action = async (selector, suffix='', method='POST') => {
    const response = page.waitForResponse(r => r.request().method() === method && r.url().endsWith(suffix || page.url().replace('/scripts/','/api/scripts/')));
    await page.locator(selector).click();
    const r = await response;
    assert.equal(r.status(), 200, await r.text());
    await page.waitForFunction(() => !busy);
    return r.json();
  };
  try {
    for (const [style, count, duration] of [['brief',1,45],['timeline',2,90],['multi_source',2,90]]) {
      await page.goto(base + '/events/' + seed.event_key);
      await page.locator('#script-style').selectOption(style);
      assert.equal(await page.locator('#script-duration').inputValue(), String(duration));
      await page.locator('#script-source-count').fill(String(count));
      await page.getByRole('button',{name:'生成脚本草稿',exact:true}).click();
      await page.waitForURL(/\/scripts\/[^/]+$/);
      await page.locator('#structured-area').waitFor();
      const current = await read(page.url().split('/').pop());
      assert.equal(current.document.structure.style, style);
      assert.equal(current.document.structure.segments.length, count);
      assert.equal(await page.locator('#script-text').getAttribute('readonly'), '');
      checks.push(style + '_form_generates_structure');
      if (style === 'timeline') await page.screenshot({path:path.join(out,'timeline.png')});
    }
    const key = page.url().split('/').pop();
    await body().getByLabel('本段口播',{exact:true}).fill('😀华星介绍新款人工智能芯片。人工核对段落。');
    assert.match(await page.locator('#script-text').inputValue(), /人工核对段落/);
    let saved = await action('#save', '/api/scripts/' + key, 'PUT');
    assert.match(saved.script_text, /人工核对段落/);
    checks.push('paragraph_edit_updates_canonical_narration');

    await body().getByRole('button',{name:'移除引用',exact:true}).click();
    saved = await action('#save', '/api/scripts/' + key, 'PUT');
    assert(saved.evidence_review.find(b=>b.id === 'body_1').issues.length);
    await action('#submit-review', '/review');
    await page.locator('#sources-checked').check();
    await page.locator('#wording-checked').check();
    assert(await page.locator('.segment-check[data-id="body_1"]').isDisabled());
    assert(await page.locator('#approve').isDisabled());
    checks.push('missing_fact_evidence_blocks_review');

    await body().getByText('添加原文证据',{exact:true}).click();
    await body().getByLabel('引用原文',{exact:true}).fill('这个原文不存在');
    await body().getByRole('button',{name:'添加引用',exact:true}).click();
    assert.match(await page.locator('#message').innerText(), /连续原文/);
    assert.equal(await body().locator('.evidence-card').count(), 0);
    checks.push('unmatched_quote_rejected_in_browser');
    const source = saved.sources.find(s=>s.excerpt.includes('😀'));
    await body().getByLabel('引用来源',{exact:true}).selectOption(source.article_key);
    await body().getByLabel('引用原文',{exact:true}).fill('华星介绍新款人工智能芯片。');
    await body().getByRole('button',{name:'添加引用',exact:true}).click();
    saved = await action('#save', '/api/scripts/' + key, 'PUT');
    const ref = saved.document.structure.segments[0].evidence[0];
    assert.equal(ref.start, 1); // emoji counts as one Unicode code point
    assert.equal(ref.article_revision, 1);
    assert.equal(ref.quote, '华星介绍新款人工智能芯片。');
    checks.push('unicode_quote_bound_to_article_version');

    await page.locator('#add-segment').click();
    let added = page.locator('.block-card').nth(3);
    await added.getByLabel('本段口播',{exact:true}).fill('这是一条测试用编辑观点。');
    await added.getByLabel('段落类型',{exact:true}).selectOption('commentary');
    await added.getByRole('button',{name:'上移',exact:true}).click();
    saved = await action('#save', '/api/scripts/' + key, 'PUT');
    assert.equal(saved.document.structure.segments[1].kind, 'commentary');
    added = page.locator('.block-card').nth(2);
    await added.getByRole('button',{name:'删除段落',exact:true}).click();
    saved = await action('#save', '/api/scripts/' + key, 'PUT');
    assert.equal(saved.document.structure.segments.length, 2);
    checks.push('add_reorder_delete_paragraph');

    await action('#submit-review', '/review');
    await page.locator('#sources-checked').check();
    await page.locator('#wording-checked').check();
    assert(await page.locator('#approve').isDisabled());
    for (const check of await page.locator('.segment-check').all()) await check.check();
    saved = await action('#approve', '/review');
    assert.equal(saved.status, 'approved');
    await action('#export', '/exports');
    assert(await page.locator('#download').isVisible());
    checks.push('explicit_paragraph_review_and_export');
    await page.evaluate(()=>window.scrollTo(0,0));
    await page.screenshot({path:path.join(out,'structured-editor.png')});
    await body().screenshot({path:path.join(out,'paragraph-evidence.png')});
    await page.locator('.card').filter({has:page.getByRole('heading',{name:'审核当前版本',exact:true})}).screenshot({path:path.join(out,'paragraph-review.png')});

    await body().getByLabel('画面说明',{exact:true}).fill('新画面说明');
    saved = await action('#save', '/api/scripts/' + key, 'PUT');
    assert.equal(saved.status, 'draft');
    assert(await page.locator('#export').isDisabled());
    checks.push('approved_edit_requires_new_review');
    await body().getByLabel('本段口播',{exact:true}).fill('并发冲突时保留的本地内容');
    const other = structuredClone(saved.document);other.notes = 'another client saved';
    const otherResponse = await page.request.put(base + '/api/scripts/' + key, {data:{expected_version:saved.version,document:other}});
    assert.equal(otherResponse.status(), 200);
    const conflict = page.waitForResponse(r=>r.url().endsWith('/api/scripts/' + key) && r.request().method() === 'PUT');
    await page.locator('#save').click();
    assert.equal((await conflict).status(), 409);
    await page.waitForFunction(() => !busy);
    assert.equal(await body().getByLabel('本段口播',{exact:true}).inputValue(), '并发冲突时保留的本地内容');
    checks.push('stale_save_preserves_local_input');
    page.once('dialog', d => d.accept());
    await page.goto(base + '/scripts/' + seed.plain_script_key);
    assert(await page.locator('#promote').isVisible());
    const original = await page.locator('#script-text').inputValue();
    saved = await action('#promote', '/structure');
    assert.equal(saved.script_text, original);
    assert.equal(saved.document.structure.segments[0].evidence.length, 0);
    assert.equal(saved.revision, 2);
    checks.push('explicit_legacy_promotion_preserves_text');
    assert.deepEqual(errors, []);
    checks.push('no_javascript_errors');
    const report = {passed:checks.length,checks,browser:browser.version(),errors,
      scope:'offline fixture; automated workflow checks are not factual approval'};
    await fs.writeFile(path.join(out,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
    console.log(JSON.stringify(report));
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
