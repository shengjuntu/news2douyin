"""Offline installed-wheel check for structured scripts and export contracts."""
import argparse
import io
import json
from pathlib import Path
from unittest.mock import patch
import zipfile

from fastapi.testclient import TestClient
from sqlmodel import Session, select

from news2douyin.collect import service as collect, llm_filter
from news2douyin.editorial.narrative import render_text
from news2douyin.server import webui
from news2douyin.server.app import create_app
from news2douyin.storage.models import Event


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    if (root / 'news.db').exists():
        parser.error('Use a new output directory; an existing database will not be overwritten')
    with patch.object(llm_filter, 'endpoint_alive', return_value=False), patch.object(webui, '_llm_alive', return_value=False):
        app = create_app(db_url='sqlite:///' + str(root / 'news.db'), storage_root=str(root / 'runs'))
        first = {'title': '华星发布新款人工智能芯片',
                 'content': '😀华星介绍新款人工智能芯片。公开测试记录了设备的推理性能和功耗，交付安排仍待后续确认。报道附有公开材料供读者核对。',
                 'country': 'cn', 'language': 'zh', 'published_at': '2026-09-29T00:00:00Z',
                 'url': 'https://source.example/story', 'source': {'domain': 'source.example'}}
        second = dict(first, title='华星发布人工智能芯片新品', url='https://independent.example/story',
                      source={'domain': 'independent.example'}, published_at='2026-09-28T00:00:00Z',
                      content='围绕华星人工智能芯片发布，另一家媒体采访了采购方。采购方表示，推理性能和功耗仍需在实际业务中验证，暂未确认采购。')
        items = [first, second, dict(first, url='https://copy.example/story', source={'domain': 'copy.example'})]
        with patch.dict(collect.PROVIDERS, {'fixture': lambda _: items}), Session(app.state.engine) as session:
            collect.create_or_update_profile(session, {'name': 'fixture', 'provider': 'fixture'})
            collect.run_collection(session, 'fixture', storage_root=root / 'runs')
            event_key = session.exec(select(Event.event_key)).one()
        checks = []
        exports = {}
        with TestClient(app) as client:
            def check(name, condition):
                assert condition, name
                checks.append(name)

            check('three_style_contracts', len(client.get('/api/script-styles').json()) == 3)
            texts = []
            for style in ('brief', 'timeline', 'multi_source'):
                result = client.post('/api/scripts/build', json={'event_key': event_key, 'style': style})
                check(style + '_built', result.status_code == 200)
                current = result.json()
                base = '/api/scripts/' + current['package_key']
                doc = current['document']
                check(style + '_versioned_evidence', all(b['evidence'][0]['article_revision'] == 1
                      for b in doc['structure']['segments']))
                check(style + '_canonical_narration', doc['script_text'] == render_text(doc['structure']))
                check(style + '_template_resource', '逐段编辑' in client.get('/scripts/' + current['package_key']).text)
                texts.append(doc['script_text'])
                current = client.post(base + '/review', json={'expected_version': current['version'], 'action': 'submit'}).json()
                review = {'expected_version': current['version'], 'action': 'approve',
                          'sources_checked': True, 'wording_checked': True}
                check(style + '_requires_paragraph_review', client.post(base + '/review', json=review).status_code == 422)
                review['segment_checks'] = {b['id']: b['hash'] for b in current['evidence_review']}
                approved = client.post(base + '/review', json=review)
                check(style + '_reviewed', approved.status_code == 200 and approved.json()['status'] == 'approved')
                current = approved.json()
                exported = client.post(base + '/exports', json={'expected_version': current['version']})
                assert exported.status_code == 200, exported.text
                raw = client.get(exported.json()['download_url']).content
                (root / (style + '.zip')).write_bytes(raw)
                with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                    revision = json.loads(archive.read('revision.json'))
                    manifest = json.loads(archive.read('manifest.json'))
                    check(style + '_compatible_export', len(archive.namelist()) == 7 and revision['schema_version'] == 1)
                    check(style + '_evidence_and_review_preserved', revision['document']['structure'] == doc['structure']
                          and manifest['review_history'][-1]['segment_checks'] == review['segment_checks']
                          and all(isinstance(v, bool) for row in manifest['review_history'] for v in row['checks'].values()))
                exports[style] = current['package_key']
            check('styles_have_different_narration', len(set(texts)) == 3)
            plain = client.post('/api/scripts/build', json={'event_key': event_key}).json()
            check('old_api_remains_plain', 'structure' not in plain['document'])
            check('invalid_style_rejected', client.post('/api/scripts/build', json={'event_key': event_key, 'style': 'unknown'}).status_code == 422)
        report = {'passed': len(checks), 'checks': checks, 'event_key': event_key,
                  'plain_script_key': plain['package_key'], 'exports': exports,
                  'scope': 'offline synthetic sources; automatic review simulates workflow only, not editorial fact-checking'}
        (root / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
