# v0.6.0 验证记录

日期：2026-09-30。Linux、Python 3.12、SQLite；Chrome for Testing 154.0.8037.57；既有 Go Video App 0.5.0 二进制。

## 已通过

| 检查 | 结果 | 覆盖范围 |
|---|---:|---|
| 全量 pytest | 144 passed，0 skipped | 124 项既有回归及 20 项结构/证据回归；包含实际视频用例 |
| 新增结构回归 | 20 项通过 | 风格差异、配置边界、Unicode 定位、8 类错误引用、缺失/未选来源、旧段落确认拒绝、正文一致、ID/空段校验、历史恢复、导出、旧稿转换与适配、API 兼容 |
| 安装后新功能检查 | 28 项通过 | 仓库外 `python -I`，三种风格、带文章版本的引用、模板资源、逐段审核要求、7 文件导出及逐段依据保留、旧 API 仍可用 |
| 安装后原流程检查 | 18 项通过 | 原采集、队列、脚本编辑/审核/恢复、CLI、提示词/模板、视频页面兼容 |
| 安装后浏览器交互 | 13 项通过 | 三种风格表单、段落编辑、缺证据拦截、错误摘录拒绝、emoji 引用定位、增删排序、逐段审核导出、修改撤销旧批准、并发冲突保留输入、显式转换旧稿、无 JS 错误 |
| Go 导入 | 3 种包各 4 项通过 | 接受版本化来源、完整口播一致、revision.json 哈希一致、重复导入幂等；Go 源码未改 |
| 发布构建 | 通过 | wheel、sdist、包内新模板、Python 编译、浏览器脚本语法、git diff --check |

全量视频测试通过 `NEWS2DOUYIN_VIDEO_FONT` 指向 Noto Sans CJK SC，FFmpeg / FFprobe 在验收环境中可用。字体只用于测试，没有打包为产品依赖。测试输出有 13 条既有依赖弃用警告（Starlette/httpx 与 mock provider 的 utcnow），没有测试失败。

浏览器在安装 wheel 后运行，未依赖源码目录导入。实际界面截图：[编辑器](validation-0.6.0/structured-editor.png)、[时间线](validation-0.6.0/timeline.png)、[原文依据](validation-0.6.0/paragraph-evidence.png)、[逐段审核](validation-0.6.0/paragraph-review.png)。同目录保存安装、浏览器、Go 导入结果 JSON。

## 验收发现并修复的问题

初次实际 Go 导入返回“制作清单格式错误”：Go 0.5.0 将 manifest 审核记录的 `checks` 解析为 `map[string]bool`，无法接收嵌套的段落哈希对象。最终导出保留布尔 checks，将逐段哈希放在同条审核记录的 `segment_checks` 字段。增加导出检查确认全部 checks 值仍为布尔值，重建/重装后重跑全量回归、28 项安装检查、13 项浏览器检查及三种包的 Go 导入，全部通过。没有通过删除证据或放宽 Go 校验规避问题。

## 结果边界

所有资料为离线虚构测试内容，自动审核只验证流程。未连接真实新闻源、真实 LLM 或 Codex；没有事实准确率、语义支持关系、生成内容质量或生产时间线准确率的量化结论。旧版 LLM 路径验证到共享结构适配与非法数据拒绝，没有真实模型端到端测试。

本次覆盖 Linux 小库，不包含 Windows 真机、大规模性能、多机部署或实际生产用户数据迁移。Go 检查止于导入，并不表示逐段画面说明会驱动 Go 分镜，也不代表真实 Codex、生产配音或逐字字幕对齐已验收。此次未完成原优化计划的所有后续项，见 [发布说明](release-0.6.0.md)。

## 复现

```bash
pip install -e '.[dev,assets,llm,video,voice-offline]'
NEWS2DOUYIN_VIDEO_FONT=/path/to/chinese-font.otf pytest -q -rs

# 安装 wheel 后，从仓库以外运行；每次使用新的输出目录
python -I /path/to/tools/smoke_installed.py
python -I /path/to/tools/smoke_structured_scripts.py --output /tmp/structured-check
python /path/to/tools/smoke_news_import.py --app /path/to/video-app \
  --script /tmp/structured-check/timeline.zip --output /tmp/timeline-import
```

对 `brief.zip`、`multi_source.zip` 同样执行 Go 检查并使用不同输出目录。

可选浏览器验证使用 Playwright，仅开发验收需要 Node；产品不依赖 Node。使用 smoke 生成的数据库启动服务，将输出目录下的 `report.json` 传给浏览器脚本：

```bash
news2douyin-server --host 127.0.0.1 --port 18191 \
  --db-url sqlite:////tmp/structured-check/news.db --storage-root /tmp/structured-check/runs
# 另一终端，使用同一网络命名空间；每次从新的 fixture 数据库开始
BROWSER_BIN=/path/to/chrome node /path/to/tools/smoke_structured_browser.cjs \
  http://127.0.0.1:18191 /tmp/structured-check/report.json /tmp/structured-browser
```

浏览器检查会创建和编辑测试稿，并转换 fixture 的纯文本稿。示例离线来源使用 `.example` 域名，不应当作为真实新闻发布。
