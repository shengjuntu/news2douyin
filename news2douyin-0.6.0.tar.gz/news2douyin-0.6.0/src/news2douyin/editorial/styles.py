"""Deterministic, evidence-backed templates. No LLM or factual inference."""
from datetime import datetime, timezone
import re

from .narrative import Block, Narrative, ScriptDocument, StyleOptions, make_evidence, render_text

STYLES = [
    {'id':'brief', 'name':'简讯', 'description':'聚焦一篇报道的核心摘录', 'defaults':{'max_sources':1,'excerpt_chars':320,'target_duration_sec':45}},
    {'id':'timeline', 'name':'时间线', 'description':'按报道发布时间排列，标注时间未知的资料', 'defaults':{'max_sources':5,'excerpt_chars':240,'target_duration_sec':90}},
    {'id':'multi_source', 'name':'多来源综述', 'description':'逐一标注报道来源，保留各自表述', 'defaults':{'max_sources':3,'excerpt_chars':300,'target_duration_sec':90}},
]
ALIASES = {'douyin_market_60s':'brief', 'fast_news':'brief', 'three_stories':'multi_source'}


def generate_document(editorial, style='brief', options=None):
    style = ALIASES.get(style, style)
    recipe = next((r for r in STYLES if r['id'] == style), None)
    if recipe is None:
        raise ValueError('未知脚本风格，请选择 brief、timeline 或 multi_source')
    config = StyleOptions.model_validate({**recipe['defaults'], **(options or {})})
    all_sources = editorial.get('sources') or []
    selected = [s for s in all_sources if not s.get('is_duplicate')] or all_sources
    def date(source):
        try:
            dt = datetime.fromisoformat(source.get('published_at', '').replace('Z', '+00:00'))
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)
        except (ValueError, TypeError):
            return datetime.max.replace(tzinfo=timezone.utc)
    if style == 'timeline':
        selected = sorted(selected, key=lambda s:(date(s), s['article_key']))
    selected = [s for s in selected if s.get('excerpt') or s.get('title')][:config.max_sources]
    segments = []
    for index, source in enumerate(selected):
        field = 'excerpt' if source.get('excerpt') else 'title'
        text = source[field]
        end = min(len(text), config.excerpt_chars)
        if end < len(text):
            boundaries = [m.end() for m in re.finditer(r'[。！？!?\n]|\.(?:\s|$)', text[:end])]
            if boundaries:
                end = boundaries[-1]
        quote = text[:end]
        name = source.get('source_domain') or '所选来源'
        if style == 'timeline':
            dt = date(source)
            label = dt.strftime('%Y-%m-%d %H:%M UTC 的报道') if dt.year < 9999 else '发布时间未知的报道'
            prefix = f'{label}，{name}记载：'
        elif style == 'multi_source':
            prefix = f'第{index+1}篇报道，来自{name}：'
        else:
            prefix = f'据{name}收录资料：'
        suffix = '（节选）' if end < len(text) else ''
        segments.append(Block(id=f'body_{index+1}', spoken=prefix+quote+suffix, kind='fact',
                              on_screen=source.get('title', '')[:500], visual='展示对应报道及原文摘录',
                              evidence=[make_evidence(source, field, 0, end)]))
    if not segments:
        segments = [Block(id='body_1', spoken='尚无可引用的来源资料，请补充后核对。', kind='fact')]
    hook_text = {'brief':'先看一条简讯。', 'timeline':'以下按报道发布时间梳理，报道时间不等于事件发生时间。',
                 'multi_source':'下面逐一列出不同报道的表述，仍需核对它们是否来自独立信息源。'}[style]
    structure = Narrative(style=style, options=config,
                          hook=Block(id='hook', spoken=hook_text, kind='transition'),
                          segments=segments,
                          closing=Block(id='closing', spoken='以上为收录资料整理，请结合原文核对。', kind='transition'))
    return ScriptDocument(title=editorial.get('event_title') or '新闻稿', script_text=render_text(structure),
                          target_duration_sec=config.target_duration_sec,
                          source_keys=[s['article_key'] for s in selected], structure=structure).model_dump(exclude_none=True)
