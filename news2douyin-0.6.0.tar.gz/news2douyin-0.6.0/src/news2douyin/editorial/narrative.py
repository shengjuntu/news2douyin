"""Canonical narrative model shared by V7 and the legacy export adapters."""
from __future__ import annotations

import hashlib
import json
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')


class Evidence(StrictModel):
    article_key: str = Field(min_length=1, max_length=128)
    article_revision: int | None = Field(default=None, ge=1)
    article_content_hash: str | None = Field(default=None, pattern=r'^[0-9a-f]{64}$')
    snapshot_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    field: Literal['title', 'excerpt']
    start: int = Field(ge=0)
    end: int = Field(gt=0)
    quote: str = Field(min_length=1, max_length=2000)


class Block(StrictModel):
    id: str = Field(pattern=r'^[a-zA-Z0-9_-]{1,60}$')
    spoken: str = Field(default='', max_length=50000)
    kind: Literal['fact', 'commentary', 'transition'] = 'fact'
    on_screen: str = Field(default='', max_length=500)
    visual: str = Field(default='', max_length=2000)
    duration_sec: float | None = Field(default=None, gt=0, le=600)
    evidence: list[Evidence] = Field(default_factory=list, max_length=10)


class StyleOptions(StrictModel):
    max_sources: int = Field(default=3, ge=1, le=8)
    excerpt_chars: int = Field(default=320, ge=80, le=1000)
    target_duration_sec: int = Field(default=60, ge=10, le=600)


class Narrative(StrictModel):
    schema_version: Literal[1] = 1
    style: Literal['brief', 'timeline', 'multi_source', 'legacy']
    template_version: str = Field(default='1.0', max_length=40)
    options: StyleOptions = Field(default_factory=StyleOptions)
    hook: Block
    segments: list[Block] = Field(min_length=1, max_length=40)
    closing: Block

    @model_validator(mode='after')
    def valid_blocks(self):
        blocks = [self.hook, *self.segments, self.closing]
        if len({block.id for block in blocks}) != len(blocks):
            raise ValueError('段落 ID 必须唯一')
        if any(not block.spoken.strip() for block in self.segments):
            raise ValueError('正文分段不能为空')
        return self


class ScriptDocument(StrictModel):
    title: str = Field(min_length=1, max_length=300)
    script_text: str = Field(min_length=1, max_length=50000)
    target_duration_sec: int = Field(default=60, ge=10, le=600)
    visual_notes: str = Field(default='', max_length=10000)
    notes: str = Field(default='', max_length=5000)
    source_keys: list[str] = Field(default_factory=list, max_length=10)
    structure: Narrative | None = None

    @field_validator('title', 'script_text')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError('title and script_text cannot be blank')
        return value.strip()

    @field_validator('source_keys')
    @classmethod
    def distinct_sources(cls, value):
        if len(set(value)) != len(value):
            raise ValueError('source_keys must be unique')
        return value

    @model_validator(mode='after')
    def consistent_text(self):
        if self.structure and self.script_text != render_text(self.structure):
            raise ValueError('结构化脚本的口播必须与开场、分段、结尾一致；请编辑对应段落')
        return self


def blocks(structure):
    if isinstance(structure, Narrative):
        structure = structure.model_dump()
    return [structure['hook'], *structure['segments'], structure['closing']]


def render_text(structure):
    return '\n'.join(block['spoken'].strip() for block in blocks(structure) if block['spoken'].strip())


def source_hash(source):
    return digest({key: source.get(key) for key in ('article_key', 'article_revision', 'article_content_hash',
                  'title', 'excerpt', 'url', 'published_at', 'source_domain')})


def make_evidence(source, field, start=0, end=None):
    value = source.get(field) or ''
    end = len(value) if end is None else end
    return Evidence(article_key=source['article_key'], article_revision=source.get('article_revision'),
                    article_content_hash=source.get('article_content_hash'), snapshot_hash=source_hash(source),
                    field=field, start=start, end=end, quote=value[start:end]).model_dump()


def validate_evidence(document, sources):
    """Reject fabricated anchors even in drafts. Missing anchors remain editable."""
    if not document.get('structure'):
        return
    known = {s['article_key']: s for s in sources}
    for block in blocks(document['structure']):
        for ref in block['evidence']:
            source = known.get(ref['article_key'])
            if not source:
                raise ValueError('段落引用的来源不在此脚本快照中')
            if (ref.get('article_revision') != source.get('article_revision') or
                    ref.get('article_content_hash') != source.get('article_content_hash') or ref['snapshot_hash'] != source_hash(source)):
                raise ValueError('段落引用的版本或校验值与来源快照不一致')
            text = source.get(ref['field']) or ''
            if not 0 <= ref['start'] < ref['end'] <= len(text) or text[ref['start']:ref['end']] != ref['quote']:
                raise ValueError('引用摘录必须与来源快照中指定位置的原文完全一致')


def evidence_review(document, sources):
    if not document.get('structure'):
        return []
    selected = set(document['source_keys'])
    result = []
    for block in blocks(document['structure']):
        if not block['spoken'].strip():
            continue
        issues = []
        if block['kind'] == 'fact' and not block['evidence']:
            issues.append('事实段缺少原文证据')
        if any(ref['article_key'] not in selected for ref in block['evidence']):
            issues.append('引用的来源未勾选为本稿来源')
        result.append({'id':block['id'], 'kind':block['kind'], 'spoken':block['spoken'],
                       'hash':digest(block), 'issues':issues,
                       'snapshot_only':any(ref.get('article_revision') is None for ref in block['evidence'])})
    return result


def plain_structure(text):
    """Explicit promotion preserves narration; no invented evidence assignments."""
    return Narrative(style='legacy', hook=Block(id='hook', kind='transition'),
                     segments=[Block(id='body_1', spoken=text)],
                     closing=Block(id='closing', kind='transition')).model_dump()


def normalize_legacy_pack(pack):
    """Legacy rule/LLM output uses the same model while keeping old template keys."""
    def block(value, id):
        if not isinstance(value, dict):
            raise ValueError('legacy script blocks must be objects')
        return Block(id=id, spoken=value.get('spoken') or '', on_screen=value.get('on_screen') or '',
                     visual=value.get('visual') or '', duration_sec=value.get('duration_sec'), kind='fact')
    raw_segments = pack.get('segments') or []
    if not isinstance(raw_segments, list):
        raise ValueError('legacy segments must be an array')
    segments = [block(value, f'body_{index+1}') for index, value in enumerate(raw_segments)]
    if not segments:
        raise ValueError('legacy script must contain at least one spoken segment')
    structure = Narrative(style='legacy', hook=block(pack.get('hook') or {}, 'hook'), segments=segments,
                          closing=block(pack.get('closing') or {}, 'closing'))
    titles = pack.get('video_title_candidates') or pack.get('titles') or []
    title = pack.get('video_title_primary') or pack.get('video_title') or (titles[0] if titles else None) or pack.get('topic') or '新闻稿'
    document = ScriptDocument(title=title, script_text=render_text(structure), structure=structure)
    result = dict(pack, document=document.model_dump(exclude_none=True), script_text=document.script_text)
    result.update({key:getattr(structure, key).model_dump(exclude_none=True) for key in ('hook', 'closing')})
    result['segments'] = [segment.model_dump(exclude_none=True) for segment in structure.segments]
    return result
