import copy
import hashlib
import io
import json
from pathlib import Path
import zipfile

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from news2douyin.editorial.narrative import (ScriptDocument, make_evidence, render_text,
    source_hash, normalize_legacy_pack)
from news2douyin.editorial.styles import generate_document
from news2douyin.export.script_builder import build_script_from_story
from news2douyin.export.render import render_markdown
from news2douyin.server.app import create_app
from news2douyin.storage.models import Article, ArticleEventLink, Event, ScriptPackage
from news2douyin.video.service import build_script_package
from news2douyin.video import workbench as wb


def pack():
    def source(key, title, excerpt, published, duplicate=False):
        return {'article_key':key,'title':title,'excerpt':excerpt,'url':'https://example.test/'+key,
                'source_domain':key+'.test','published_at':published,'is_duplicate':duplicate,
                'article_revision':2,'article_content_hash':hashlib.sha256(key.encode()).hexdigest()}
    return {'event_title':'技术试验', 'sources':[
        source('new','近期报道','😀试验数据为 12。设备仍需进一步验证。','2026-09-30T00:00:00Z'),
        source('older','较早报道','早期试验已经开始。测试团队公布了范围。','2026-09-28T16:00:00-08:00'),
        source('copy','转载资料','转载不构成独立核验。','2026-09-29T00:00:00Z',True),
        source('undated','日期未知报道','这条报道没有有效发布时间。',''),
    ]}


def seed(session):
    session.add(Event(event_key='event',event_title='技术试验'))
    for source in pack()['sources']:
        session.add(Article(article_key=source['article_key'],title=source['title'],content=source['excerpt'],
            published_at=source['published_at'],source_domain=source['source_domain'],url=source['url'],is_duplicate=source['is_duplicate']))
        session.add(ArticleEventLink(event_key='event',article_key=source['article_key']))
    session.commit()


@pytest.fixture
def structured(engine,tmp_path):
    with Session(engine) as s:
        seed(s)
        package=build_script_package(s,'event',style='multi_source',output_root=tmp_path/'packages')
        return wb.script_detail(s,package.package_key)


def checks(current):
    return {'sources_checked':True,'wording_checked':True,
            'segment_checks':{b['id']:b['hash'] for b in current['evidence_review']}}


def save(s,current,document):
    document['script_text']=render_text(document['structure'])
    return wb.save_script(s,current['package_key'],expected_version=current['version'],document=document)


def approve(s,current):
    current=wb.review_script(s,current['package_key'],expected_version=current['version'],action='submit')
    return wb.review_script(s,current['package_key'],expected_version=current['version'],action='approve',checks=checks(current))


def test_styles_change_selection_order_and_actual_spoken_content():
    brief=generate_document(pack(),'brief')
    timeline=generate_document(pack(),'timeline')
    multi=generate_document(pack(),'multi_source')
    assert len({d['script_text'] for d in [brief,timeline,multi]})==3
    assert brief['source_keys']==['new']
    assert timeline['source_keys']==['older','new','undated']
    assert multi['source_keys']==['new','older','undated']
    assert '报道时间不等于事件发生时间' in timeline['script_text']
    assert '发布时间未知' in timeline['script_text']
    assert 'copy' not in timeline['source_keys']
    for doc in [brief,timeline,multi]:
        assert ScriptDocument.model_validate(doc).script_text==render_text(doc['structure'])
        for b in doc['structure']['segments']:
            assert b['evidence'][0]['article_revision']==2


def test_style_options_snapshot_and_boundaries():
    doc=generate_document(pack(),'multi_source',{'max_sources':1,'excerpt_chars':80,'target_duration_sec':30})
    assert doc['structure']['options']=={'max_sources':1,'excerpt_chars':80,'target_duration_sec':30}
    assert len(doc['structure']['segments'])==1 and doc['target_duration_sec']==30
    for style,options in [('unknown',{}),('brief',{'max_sources':9}),('brief',{'template':'{arbitrary}'})]:
        with pytest.raises(ValueError):generate_document(pack(),style,options)


def test_evidence_uses_unicode_codepoint_offsets_and_actual_version():
    source=pack()['sources'][0]
    ref=make_evidence(source,'excerpt',1,9)
    assert ref['quote']==source['excerpt'][1:9]
    assert ref['snapshot_hash']==source_hash(source)
    doc=generate_document(pack(),'brief')
    from news2douyin.editorial.narrative import validate_evidence
    doc['structure']['segments'][0]['evidence']=[ref]
    validate_evidence(doc,pack()['sources'])


@pytest.mark.parametrize('field,value',[
    ('quote','虚构引文'),('start',999),('end',999),('article_key','unknown'),
    ('article_revision',77),('article_content_hash','f'*64),('snapshot_hash','0'*64),('field','title')])
def test_fabricated_or_misaligned_evidence_never_persists(engine,structured,field,value):
    doc=copy.deepcopy(structured['document'])
    doc['structure']['segments'][0]['evidence'][0][field]=value
    with Session(engine) as s:
        with pytest.raises(ValueError):save(s,structured,doc)
        assert wb.script_detail(s,structured['package_key'])['revision']==1


def test_missing_evidence_can_save_draft_but_cannot_approve(engine,structured):
    doc=copy.deepcopy(structured['document']);doc['structure']['segments'][0]['evidence']=[]
    with Session(engine) as s:
        current=save(s,structured,doc)
        assert any(b['issues'] for b in current['evidence_review'])
        current=wb.review_script(s,current['package_key'],expected_version=current['version'],action='submit')
        with pytest.raises(ValueError,match='证据'):wb.review_script(s,current['package_key'],expected_version=current['version'],action='approve',checks=checks(current))


def test_unselected_source_blocks_approval_even_when_anchor_valid(engine,structured):
    doc=copy.deepcopy(structured['document']);doc['source_keys']=doc['source_keys'][1:]
    with Session(engine) as s:
        current=save(s,structured,doc)
        with pytest.raises(ValueError,match='来源'):approve(s,current)


def test_review_checks_bind_exact_current_paragraphs(engine,structured):
    with Session(engine) as s:
        approved=approve(s,structured)
        stale=checks(approved)
        doc=copy.deepcopy(approved['document']);doc['structure']['segments'][0]['spoken']+=' 人工补充，待核对。'
        current=save(s,approved,doc)
        assert current['status']=='draft' and current['approved_revision'] is None
        current=wb.review_script(s,current['package_key'],expected_version=current['version'],action='submit')
        with pytest.raises(ValueError,match='逐段'):wb.review_script(s,current['package_key'],expected_version=current['version'],action='approve',checks=stale)
        reviewed=wb.review_script(s,current['package_key'],expected_version=current['version'],action='approve',checks=checks(current))
        assert reviewed['status']=='approved'


def test_flattened_text_and_structure_cannot_diverge_or_be_silently_removed(engine,structured):
    for mutate in [lambda d:d.update(script_text='只改扁平正文'),lambda d:d.pop('structure')]:
        doc=copy.deepcopy(structured['document']);mutate(doc)
        with Session(engine) as s,pytest.raises(ValueError):
            wb.save_script(s,structured['package_key'],expected_version=1,document=doc)


def test_duplicate_block_ids_and_blank_body_are_rejected(structured):
    for mutate in [lambda d:d['structure']['segments'][0].update(id='hook'),
                   lambda d:d['structure']['segments'][0].update(spoken='')]:
        doc=copy.deepcopy(structured['document']);mutate(doc);doc['script_text']=render_text(doc['structure'])
        with pytest.raises(ValueError):ScriptDocument.model_validate(doc)


def test_export_and_restore_keep_exact_structure_evidence_and_old_archive(engine,structured):
    with Session(engine) as s:
        approved=approve(s,structured)
        exported=wb.export_script(s,approved['package_key'],expected_version=approved['version'])
        _,raw=wb.read_export(s,approved['package_key'],exported['export_key'])
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            assert len(archive.namelist())==7
            revision=json.loads(archive.read('revision.json'))
            assert revision['schema_version']==1
            assert revision['document']['structure']==approved['document']['structure']
            assert archive.read('script.txt').decode()==render_text(revision['document']['structure'])
            assert '逐段来源依据' in archive.read('script.md').decode()
            manifest=json.loads(archive.read('manifest.json'))
            assert manifest['review_history'][-1]['segment_checks']==checks(approved)['segment_checks']
            assert all(isinstance(v, bool) for row in manifest['review_history'] for v in row['checks'].values())
        doc=copy.deepcopy(approved['document']);doc['structure']['segments'].reverse();current=save(s,approved,doc)
        restored=wb.save_script(s,current['package_key'],expected_version=current['version'],document=None,restore_revision=1)
        assert restored['document']==structured['document'] and restored['status']=='draft'
        assert wb.read_export(s,approved['package_key'],exported['export_key'])[1]==raw


def test_plain_promotion_is_explicit_preserves_text_and_does_not_guess_evidence(engine,tmp_path):
    with Session(engine) as s:
        seed(s);p=build_script_package(s,'event',output_root=tmp_path/'packages');old=wb.script_detail(s,p.package_key)
        assert 'structure' not in old['document']
        upgraded=wb.save_script(s,p.package_key,expected_version=old['version'],document=None,promote=True)
        assert upgraded['revision']==2 and upgraded['script_text']==old['script_text']
        assert upgraded['document']['structure']['segments'][0]['evidence']==[]
        assert json.loads(wb.get_revision(s,p.package_key,1).payload_json)['document']==old['document']
        assert wb.save_script(s,p.package_key,expected_version=upgraded['version'],document=None,promote=True)['revision']==2


def test_legacy_adapter_and_adoption_share_model_and_preserve_existing_blocks(engine,tmp_path):
    old=build_script_from_story({'topic':'历史稿','key_points':['原有段落一','原有段落二']},['#测试'])
    assert render_text(old['document']['structure'])==old['script_text']
    assert '原有段落一' in render_markdown('templates/douyin/fast_news.j2',old)
    with Session(engine) as s:
        seed(s);root=tmp_path/'legacy';root.mkdir()
        s.add(ScriptPackage(package_key='legacy',event_key='event',script_text=old['script_text'],
                            script_json=json.dumps(old,ensure_ascii=False),output_dir=str(root)));s.commit()
        adopted=wb.adopt_legacy(s,'legacy')
        promoted=wb.save_script(s,'legacy',expected_version=adopted['version'],document=None,promote=True)
        assert len(promoted['document']['structure']['segments'])==2
        assert promoted['script_text']==old['script_text']
        assert all(not b['evidence'] for b in promoted['document']['structure']['segments'])
    bad=copy.deepcopy(old);bad['segments']=[{'spoken':{'invalid':'nested object'}}]
    with pytest.raises(ValueError):normalize_legacy_pack(bad)


def test_new_api_is_structured_only_when_requested_and_old_api_stays_usable(tmp_path):
    app=create_app(db_url=f'sqlite:///{tmp_path}/api.db',storage_root=str(tmp_path/'runs'))
    with Session(app.state.engine) as s:seed(s)
    client=TestClient(app)
    assert len(client.get('/api/script-styles').json())==3
    assert 'structure' not in client.post('/api/scripts/build',json={'event_key':'event'}).json()['document']
    result=client.post('/api/scripts/build',json={'event_key':'event','style':'timeline','style_options':{'max_sources':2}})
    assert result.status_code==200
    current=result.json();assert len(current['document']['structure']['segments'])==2
    base='/api/scripts/'+current['package_key']
    assert client.get('/scripts/'+current['package_key']).status_code==200
    current=client.post(base+'/review',json={'expected_version':current['version'],'action':'submit'}).json()
    assert client.post(base+'/review',json={'expected_version':current['version'],'action':'approve','sources_checked':True,'wording_checked':True}).status_code==422
    approved=client.post(base+'/review',json={'expected_version':current['version'],'action':'approve',**checks(current)})
    assert approved.status_code==200
    assert client.post('/api/scripts/build',json={'event_key':'event','style':'unknown'}).status_code==422
    assert client.post('/api/scripts/build',json={'event_key':'event','style':'brief','style_options':{'path':'/tmp/template'}}).status_code==422
